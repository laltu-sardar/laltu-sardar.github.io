#include <sys/types.h>   // pid_t
#include <stdio.h>       // printf() and fprintf()
#include <unistd.h>      // fork() execlp()
#include <sys/wait.h>    // wait()

int main()
{
    pid_t pid;

    /* fork a child process */
    pid = fork();

    if (pid < 0) { /* error occurred */
        fprintf(stderr, "Fork Failed\n");
        return 1;
    }
    
    execlp("./print_names", "print_names", NULL);
    wait(NULL);
    printf("\nChild Complete\n");

    return 0;
}
