run followings 
	gcc print_names.c -o print_names
	gcc child_process.c -o child_process
	./child_process
