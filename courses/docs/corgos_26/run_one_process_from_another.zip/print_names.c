#include <stdio.h>
#include <stdlib.h>

int main() {
    FILE *file;
    char line[256];

    // Open the file in read mode
    file = fopen("dsc_315_students.txt", "r");

    // Check if file opened successfully
    if (file == NULL) {
        printf("Error: Could not open the file.\n");
        return 1;
    }

    // Read each line and print it
    while (fgets(line, sizeof(line), file) != NULL) {
        printf("%s", line);
    }

    // Close the file
    fclose(file);

    return 0;
}
