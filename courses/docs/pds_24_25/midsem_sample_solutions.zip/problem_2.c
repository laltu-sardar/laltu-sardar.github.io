#include<stdio.h>
#include<stdlib.h>
#include <limits.h>
// Define the ure for the BST node
typedef struct node {
    int data;
    struct  node* left;
    struct node* right;
}Node;

// Declare functions used in the program
 Node* create_node(int ); 
 void inorder(Node* ) ;
 Node* insert( Node* , int );
 Node* replace_value( Node* , int , int );
int is_bst_helper( Node* , int , int ) ;
int is_bst( Node* ) ;
void menu();


// Function to create a new node
 Node* create_node(int data) {
     Node* new_node = ( Node*) malloc(sizeof( Node));
    new_node->data = data;
    new_node->left = NULL;
    new_node->right = NULL;
    return new_node;
}

// Function for inorder traversal of a binary tree
void inorder(Node* root) {
    if (root == NULL) {
        return; // Base case: If the node is NULL, do nothing
    }

    inorder(root->left);  // First, traverse the left subtree
    printf("%d ", root->data);  // Then, visit the root (print the node's data)
    inorder(root->right);  // Finally, traverse the right subtree
}

// Function to insert a value into the BST
 Node* insert( Node* root, int data) {
    if (root == NULL) {
        return create_node(data); // Insert at the root if tree is empty
    }

    if (data < root->data) {
        root->left = insert(root->left, data); // Insert in the left subtree
    } else if (data > root->data) {
        root->right = insert(root->right, data); // Insert in the right subtree
    }
    return root;
}

// Function to replace a target value with a new value in the BST
 Node* replace_value( Node* root, int target, int new_value) {
    if (root == NULL) {
        return NULL; // Target not found
    }

    if (root->data == target) {
        root->data = new_value; // Replace the target value with new_value
    } else if (target < root->data) {
        root->left = replace_value(root->left, target, new_value); // Look in the left subtree
    } else {
        root->right = replace_value(root->right, target, new_value); // Look in the right subtree
    }
    return root;
}

// Helper function to check if a given tree is a BST
int is_bst_helper( Node* root, int min, int max) {
    if (root == NULL) {
        return 1; // An empty tree is a valid BST
    }

    if (root->data <= min || root->data >= max) {
        return 0; // Violates the BST property
    }

    // Recursively check the left and right subtrees with updated bounds
    return is_bst_helper(root->left, min, root->data) &&
           is_bst_helper(root->right, root->data, max);
}

// Wrapper function to check if a given tree is a BST
int is_bst( Node* root) {
    return is_bst_helper(root, INT_MIN, INT_MAX);
}

void menu(){
    printf("\nMenu:\n");
    printf("1. Insert a value into the BST\n");
    printf("2. Replace a value in the BST\n");
    printf("3. Check if the tree is a BST\n");
    printf("4. Display Inorder\n");
    printf("0. Exit\n");
    printf("Enter your choice: ");
}


int main() {
     Node* root = NULL;
    int choice, value, target, new_value;

    while (1) {
        menu();    
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter a value to insert: ");
                scanf("%d", &value);
                root = insert(root, value);
                printf("Value inserted.\n");
                break;

            case 2:
                printf("Enter the target value to replace: ");
                scanf("%d", &target);
                printf("Enter the new value: ");
                scanf("%d", &new_value);
                root = replace_value(root, target, new_value);
                printf("Value replaced.\n");
                break;

            case 3:
                if (is_bst(root)) {
                    printf("The tree is a valid BST.\n");
                } else {
                    printf("The tree is NOT a valid BST.\n");
                }
                break;
            case 4:
                inorder(root);
                break;
            case 0:
                exit(0);

            default:
                printf("Invalid choice! Please try again.\n");
        }
    }

    return 0;
}

