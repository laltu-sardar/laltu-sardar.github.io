#include<stdio.h>
#include <stdlib.h>

// Function to allocate 1D array memory with error handling
void* allocate_1d_array(size_t size, int unit) {
    void *array = (void *)malloc(size * unit);
    if (array == NULL) {
        printf( "Memory allocation failed for size %zu\n", size);
        exit(0); // Exit the program if memory allocation fails
    }
    return array;
}

// Function to open a file with error handling
FILE* open_file(const char *fileName, const char *mode) {
    FILE *file = fopen(fileName, mode);
    if (file == NULL) {
        printf( "Error opening file: %s\n", fileName);
        exit(0); // Exit the program if file opening fails
    }
    return file;
}

// Function to close a file with error handling
void close_file(FILE *file) {
    if (fclose(file) != 0) {
        printf("Error closing file\n");
        exit(0); // Exit the program if file closing fails
    }
}
