#include <stdio.h>
#include <stdlib.h>
#include "myLibrary.h"

typedef struct {
    int size; // Dimension of the matrix
    int *cols; // Array to store the column indices of non-zero elements
    int *values; // Array to store the non-zero values
} mono_matrix;

// Function to scan a monomial matrix from a file
mono_matrix ScanMatrix(const char *fileName) {
    FILE *file = open_file(fileName, "r");
    mono_matrix mat;
    fscanf(file, "%d", &mat.size);
    
    mat.cols = (int *) allocate_1d_array (mat.size, sizeof(int));
    mat.values = (int *)allocate_1d_array (mat.size, sizeof(int));
    
    int temp_value;
    for (int i = 0; i < mat.size; i++) {
        for (int j = 0; j < mat.size; j++) {
            fscanf(file, "%d", &temp_value);
            if (temp_value) {
                mat.cols[i] = j; // Store column index
                mat.values[i] = temp_value; // Store value
            }
        }
    }
    fclose(file);
    return mat;
}

// Function to multiply two monomial matrices
mono_matrix MultMatrix(mono_matrix A, mono_matrix B) {
    mono_matrix C;
    C.size = A.size;
    C.cols = (int *)allocate_1d_array (C.size, sizeof(int));
    C.values = (int *)allocate_1d_array (C.size, sizeof(int));
    
    for (int i = 0; i < C.size; i++) {
        C.cols[i] = B.cols[A.cols[i]];
        C.values[i] = B.values[A.cols[i]] * A.values[i];
    }
    
    return C;
}

// Function to display the matrix
void display_matrix(mono_matrix mat) {
    for (int i = 0; i < mat.size; i++) {
        for (int j = 0; j < mat.size; j++) {
            if (mat.cols[i] == j) {
                printf("%d ", mat.values[i]);
            } else {
                printf("0 ");
            }
        }
        printf("\n");
    }
}

// Free allocated memory for the matrix
void free_mono_matrix(mono_matrix mat) {
    free(mat.cols);
    free(mat.values);
}

int main() {
    mono_matrix A = ScanMatrix("matrix1.txt");
    display_matrix(A);
    mono_matrix B = ScanMatrix("matrix2.txt");
    display_matrix(B);

    mono_matrix C = MultMatrix(A, B);
    
    printf("Resulting Matrix:\n");
    display_matrix(C);
    
    // Free allocated memory
    free_mono_matrix(A);
    free_mono_matrix(B);
    free_mono_matrix(C);
    
    return 0;
}

