#include <stdio.h>
#include <stdlib.h>
#include "myLibrary.h"

// Structure for a doubly linked list node
struct Node {
    int data;
    struct Node* next;
    struct Node* prev;
};

// Function to create a new node
struct Node* create_node(int data) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = data;
    newNode->next = NULL;
    newNode->prev = NULL;
    return newNode;
}

// Function to add a node after the k-th node
void add_after_k(struct Node** head, int k, int data) {
    struct Node* newNode = create_node(data);
    if (*head == NULL) { // If the list is empty
        *head = newNode;
        return;
    }

    struct Node* current = *head;
    int count = 0;

    while (current != NULL && count < k) {
        current = current->next;
        count++;
    }

    // If there are fewer than k nodes, add at the end
    if (current == NULL) {
        // Traverse to the end of the list
        current = *head;
        while (current->next != NULL) {
            current = current->next;
        }
        current->next = newNode;
        newNode->prev = current;
    } else {
        // Insert the new node after the k-th node
        newNode->next = current->next;
        newNode->prev = current;

        if (current->next != NULL) {
            current->next->prev = newNode;
        }
        current->next = newNode;
    }
}

// Function to reverse the doubly linked list
void reverse_list(struct Node** head) {
    struct Node* temp = NULL;
    struct Node* current = *head;

    // Swap next and prev for all nodes
    while (current != NULL) {
        temp = current->prev;
        current->prev = current->next;
        current->next = temp;
        current = current->prev; // Move to the next node (which is the previous one)
    }

    // Adjust head pointer
    if (temp != NULL) {
        *head = temp->prev; // After the loop, temp points to the last node
    }
}

// Function to display the doubly linked list
void display_list(struct Node* head) {
    struct Node* current = head;
    while (current != NULL) {
        printf("%d ", current->data);
        current = current->next;
    }
    printf("\n");
}

// Main function to test the doubly linked list functionalities
int main() {
    struct Node* head = NULL;
    int choice, data, k;

    do {
        printf("\nDoubly Linked List Menu:\n");
        printf("1. Add a node after k-th node\n");
        printf("2. Reverse the list\n");
        printf("3. Display the list\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter the value to add: ");
                scanf("%d", &data);
                printf("Enter k (0 for first node): ");
                scanf("%d", &k);
                add_after_k(&head, k, data);
                break;
            case 2:
                reverse_list(&head);
                printf("List reversed.\n");
                break;
            case 3:
                printf("Doubly Linked List: ");
                display_list(head);
                break;
            case 4:
                printf("Exiting...\n");
                break;
            default:
                printf("Invalid choice! Please try again.\n");
        }
    } while (choice != 4);

    // Free memory (not shown in the menu but should be handled)
    struct Node* current = head;
    while (current != NULL) {
        struct Node* temp = current;
        current = current->next;
        free(temp);
    }

    return 0;
}

