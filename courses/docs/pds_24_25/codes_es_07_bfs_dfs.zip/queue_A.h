#ifndef QUEUE_A_H
#define QUEUE_A_H

#include <stdio.h>
#include <stdlib.h>

// Define the Queue structure
typedef struct Queue {
    int *data;     // Dynamic array for queue storage
    int front;     // Index of the front element
    int rear;      // Index of the rear element
    int maxSize;   // Maximum size of the queue
} Queue;

// Function prototypes
void init_queue(Queue *q, int size);
int isEmpty(Queue *q);
int isFull(Queue *q);
void enqueue(Queue *q, int value);
int dequeue(Queue *q);
void display(Queue *q);
void freeQueue(Queue *q);

// Function definitions

// Initialize the queue with dynamic size
void init_queue(Queue *q, int size) {
    q->data = (int *)malloc(size * sizeof(int));
    if (q->data == NULL) {
        printf("Memory allocation failed.\n");
        exit(1);
    }
    q->front = -1;
    q->rear = -1;
    q->maxSize = size;
}

// Check if the queue is empty
int isEmpty(Queue *q) {
    return q->front == -1;
}

// Check if the queue is full
int isFull(Queue *q) {
    return (q->rear + 1) % q->maxSize == q->front;
}

// Enqueue an element into the queue
void enqueue(Queue *q, int value) {
    if (isFull(q)) {
        printf("Queue is full. Cannot enqueue %d.\n", value);
        return;
    }
    if (isEmpty(q)) {
        q->front = 0;  // Set front to 0 when adding the first element
    }
    q->rear = (q->rear + 1) % q->maxSize;
    q->data[q->rear] = value;
    //printf("Enqueued %d.\n", value);
}

// Dequeue an element from the queue
int dequeue(Queue *q) {
    if (isEmpty(q)) {
        printf("Queue is empty. Cannot dequeue.\n");
        return -1;
    }
    int dequeuedValue = q->data[q->front];
    if (q->front == q->rear) {
        // Queue becomes empty after removing the last element
        q->front = q->rear = -1;
    } else {
        q->front = (q->front + 1) % q->maxSize;
    }
    //printf("Dequeued %d.\n", dequeuedValue);
    return dequeuedValue;
}

// Display the queue elements
void display(Queue *q) {
    if (isEmpty(q)) {
        printf("Queue is empty.\n");
        return;
    }
    printf("Queue: ");
    int i = q->front;
    while (1) {
        printf("%d ", q->data[i]);
        if (i == q->rear) {
            break;
        }
        i = (i + 1) % q->maxSize;
    }
    printf("\n");
}

// Free the dynamically allocated memory for the queue
void freeQueue(Queue *q) {
    free(q->data);
    q->data = NULL;
    q->front = q->rear = -1;
    q->maxSize = 0;
}

#endif

