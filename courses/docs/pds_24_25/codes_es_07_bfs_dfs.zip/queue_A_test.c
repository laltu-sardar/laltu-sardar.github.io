#include "queue_A.h"

int main() {
    Queue q;
    int size;

    printf("Enter the size of the queue: ");
    scanf("%d", &size);

    init_queue(&q, size);

    enqueue(&q, 10);
    enqueue(&q, 20);
    enqueue(&q, 30);
    display(&q);

    dequeue(&q);
    display(&q);

    enqueue(&q, 40);
    enqueue(&q, 50);  // This will work if space is reused correctly
    display(&q);

    freeQueue(&q);
    return 0;
}

