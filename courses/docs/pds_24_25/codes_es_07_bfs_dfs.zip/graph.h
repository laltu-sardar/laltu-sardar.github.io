#ifndef GRAPH_H
#define GRAPH_H

#include <stdio.h>
#include <stdlib.h>

// Define the Node structure for adjacency list
typedef struct Node {
    int vertex;
    struct Node *next;
} Node;

// Define the Graph structure
typedef struct graph_t {
    int n;            // Number of vertices
    Node **AdjLists;  // Array of pointers to adjacency lists
} Graph;

// Function prototypes
int read_n(FILE *file);
Graph* init_graph(int n);
void add_edge(Graph *graph, int a, int b);
void read_edges(Graph *graph, FILE *file);
void display_graph(Graph *graph);
void display_neighbor(Graph *graph, int k);
void free_graph(Graph *graph);


// Function to read the number of vertices (n) from the input file
int read_n(FILE *file) {
    int n;
    fscanf(file, "%d", &n);
    return n;
}

// Function to initialize the graph structure
Graph* init_graph(int n) {
    Graph *graph = (Graph *)malloc(sizeof(Graph));
    if (!graph) {
        printf("Memory allocation failed for graph.\n");
        exit(1);
    }
    graph->n = n;
    graph->AdjLists = (Node **)malloc(n * sizeof(Node *));
    if (!graph->AdjLists) {
        printf("Memory allocation failed for adjacency list.\n");
        exit(1);
    }
    for (int i = 0; i < n; i++) {
        graph->AdjLists[i] = NULL;
    }
    return graph;
}

// Function to create a new node
Node* create_node(int vertex) {
    Node *newNode = (Node *)malloc(sizeof(Node));
    if (!newNode) {
        printf("Memory allocation failed for node.\n");
        exit(1);
    }
    newNode->vertex = vertex;
    newNode->next = NULL;
    return newNode;
}

// Function to add an edge to the graph (undirected graph)
void add_edge(Graph *graph, int a, int b) {
    // Add b to a's adjacency list
    Node *newNode = create_node(b);
    newNode->next = graph->AdjLists[a];
    graph->AdjLists[a] = newNode;

    // Add a to b's adjacency list (since the graph is undirected)
    newNode = create_node(a);
    newNode->next = graph->AdjLists[b];
    graph->AdjLists[b] = newNode;
}

// Function to read edges from the input file and add them to the graph
void read_edges(Graph *graph, FILE *file) {
    int a, b;
    while (fscanf(file, "%d %d", &a, &b) != EOF) {
        add_edge(graph, a, b);
    }
}

// Function to display the graph's adjacency list representation
void display_graph(Graph *graph) {
    printf("Graph adjacency list representation:\n");
    for (int i = 0; i < graph->n; i++) {
        printf("Vertex %d: ", i);
        Node *temp = graph->AdjLists[i];
        while (temp) {
            printf("%d -> ", temp->vertex);
            temp = temp->next;
        }
        printf("NULL\n");
    }
}

// Function to display neighbors of a specific vertex
void display_neighbor(Graph *graph, int k) {
    if (k < 0 || k >= graph->n) {
        printf("Vertex %d does not exist.\n", k);
        return;
    }
    printf("Neighbors of vertex %d: ", k);
    Node *temp = graph->AdjLists[k];
    while (temp) {
        printf("%d ", temp->vertex);
        temp = temp->next;
    }
    printf("\n");
}

// Function to free the memory allocated for the graph
void free_graph(Graph *graph) {
    for (int i = 0; i < graph->n; i++) {
        Node *temp = graph->AdjLists[i];
        while (temp) {
            Node *toFree = temp;
            temp = temp->next;
            free(toFree);
        }
    }
    free(graph->AdjLists);
    free(graph);
}


#endif

