#ifndef UTILS_H
#define UTILS_H

#include <stdio.h>
#include <stdlib.h>

// Memory management functions
void* allocate_1d_array(int length, int unit_size);
void** allocate_2d_array(int rows, int cols, int unit_size);
void free_2d_array(void** array, int rows);

// File handling functions
FILE* open_file(const char* filename, const char* mode);
void close_file(FILE* file);

// Dynamically allocate a 1D array
void* allocate_1d_array(int length, int unit_size) {
    void* array = malloc(length * unit_size);
    if (!array) {
        printf("Memory allocation failed for 1D array.\n");
        exit(1);
    }
    return array;
}

// Dynamically allocate a 2D array
void** allocate_2d_array(int rows, int cols, int unit_size) {
    void** array = (void**)malloc(rows * sizeof(void*));
    if (!array) {
        printf("Memory allocation failed for 2D array.\n");
        exit(1);
    }
    for (int i = 0; i < rows; i++) {
        array[i] = malloc(cols * unit_size);
        if (!array[i]) {
            printf("Memory allocation failed for row %d of 2D array.\n", i);
            exit(1);
        }
    }
    return array;
}

// Free a 2D array
void free_2d_array(void** array, int rows) {
    for (int i = 0; i < rows; i++) {
        free(array[i]);
    }
    free(array);
}

// Open a file and handle errors
FILE* open_file(const char* filename, const char* mode) {
    FILE* file = fopen(filename, mode);
    if (!file) {
        printf("Error opening file: %s\n", filename);
    }
    return file;
}

// Close a file and handle errors
void close_file(FILE* file) {
    if (fclose(file) != 0) {
        printf("Error closing file.\n");
    }
}


#endif

