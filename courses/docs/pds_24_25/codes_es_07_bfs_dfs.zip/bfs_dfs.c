#include "graph.h"
#include "queue_A.h"
#include "utils.h"

// BFS Function
void bfs(Graph *graph, int startVertex) {
    int *visited = allocate_1d_array (graph->n , sizeof(int)); // Initialize visited array
    for (int i = 0; i < graph->n; i++) {
        visited[i] = 0;  // Mark all vertices as not visited
    }

    // Create a queue for BFS
    Queue *queue=malloc(sizeof(struct Queue));
    init_queue(queue,graph->n);

    // Start BFS
    visited[startVertex] = 1;  // Mark the start vertex as visited
    enqueue(queue, startVertex);

    printf("BFS Traversal starting from vertex %d:\n", startVertex);
    while (!isEmpty(queue)) {
        int currentVertex = dequeue(queue);
        printf("%d ", currentVertex);

        // Traverse the adjacency list of the current vertex
        Node *temp = graph->AdjLists[currentVertex];
        while (temp) {
            int adjVertex = temp->vertex;
            if (!visited[adjVertex]) {
                visited[adjVertex] = 1;  // Mark as visited
                enqueue(queue, adjVertex);
            }
            temp = temp->next;
        }
    }
    printf("\n");
    
    free(visited);// Free resources
    freeQueue(queue);
}



// DFS Helper Function
void dfs_recursion(Graph *graph, int vertex, int *visited) {
    visited[vertex] = 1;
    printf("%d ", vertex);

    Node *temp = graph->AdjLists[vertex];
    while (temp) {
        int adjVertex = temp->vertex;
        if (!visited[adjVertex]) {
            dfs_recursion(graph, adjVertex, visited);
        }
        temp = temp->next;
    }
}

// DFS Function
void dfs(Graph *graph, int startVertex) {
    int *visited = allocate_1d_array (graph->n , sizeof(int));
    for (int i = 0; i < graph->n; i++) 
        visited[i] = 0;

    printf("DFS Traversal starting from vertex %d:\n", startVertex);
    dfs_recursion(graph, startVertex, visited);
    printf("\n");

    free(visited);
}

// Test BFS in the main function
int main() {
    FILE *file = open_file("graph_input.txt", "r");
    int n = read_n(file);    // Read the number of vertices
    Graph *graph = init_graph(n);// Initialize the graph
    read_edges(graph, file);// Read edges from the file
    close_file(file);
    display_graph(graph); // Display the graph

    // Perform BFS
    int startVertex;
    printf("\nEnter the starting vertex for BFS: ");
    scanf("%d", &startVertex);
    bfs(graph, startVertex);
    
    printf("\nEnter the starting vertex for DFS: ");
    scanf("%d", &startVertex);
    dfs(graph, startVertex);

    // Free the graph memory
    free_graph(graph);

    return 0;
}

