#include "graph.h"

int main() {
    FILE *file = fopen("graph_input.txt", "r");
    if (!file) {
        printf("Error opening file.\n");
        return 1;
    }

    // Read the number of vertices
    int n = read_n(file);

    // Initialize the graph
    Graph *graph = init_graph(n);

    // Read edges from the file
    read_edges(graph, file);
    fclose(file);

    // Display the graph
    printf("Graph adjacency list representation:\n");
    display_graph(graph);

    // Display neighbors of a specific vertex
    int vertex;
    printf("\nEnter a vertex to find its neighbors: ");
    scanf("%d", &vertex);
    display_neighbor(graph, vertex);

    // Free the graph memory
    free_graph(graph);

    return 0;
}

