font_size=12;

data_A = load("input_matrix_A.txt");
data_B = load("input_matrix_B.txt");
data_C = load("input_matrix_C.txt");

plot(data_A, data_B);
hold on
plot(data_A, data_C);
hold off
grid on

l= {'1st', '2nd-plot-legend'};
legend(gca,l,'FontSize',font_size,'Location','northeast');
xlabel('x-axis-name', 'FontSize', font_size);
ylabel('y-axis-name', 'FontSize', font_size);
set(gca,'FontSize',font_size);


print -dpdf testGraph.pdf
