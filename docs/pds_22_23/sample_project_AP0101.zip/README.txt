Run as 
gcc -g -Wall test_AP0101.c src_AP0101.c -o AP0101
./AP0101
