/************************************************************
FileName: test_AP0101.c
Problem ID: AP0101
Name: Laltu Sardar
Collaborators: NA
Acknowledgements: NA
Time Spent: 
************************************************************/

#include<stdio.h>
#include"AP0101.h"

int main(){
    int N, i, no_of_tests, j;
    int *arr;

    FILE *inp_file_ptr;
    inp_file_ptr = fopen("input_AP0101.txt","r"); //1. New FileName
    
  
    ///first scans no_of_tests
    fscanf(inp_file_ptr, "%d", &no_of_tests);
    
    //for each test case we scan N and array
    for (j = 0; j< no_of_tests; j++)
    {
        fscanf(inp_file_ptr, "%d", &N);
        arr =(int *) myMalloc(N*sizeof(int));       //Allocating dynamic memory for the array
        for (i=0;i<N;i++)       //loop to scan array
        {
            fscanf(inp_file_ptr, "%d", &arr[i]);   
        } 
        if_palindrome(arr, N);  // we call the function here after taking inputs
        free(arr);              //Each time it is mandatory to free the used array
    }
       
    fclose(inp_file_ptr);   //closing the test file
   
    return 0;
}
