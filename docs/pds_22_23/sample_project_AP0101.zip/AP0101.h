/************************************************************
FileName: AP0101.h
Problem ID: AP0101
Name: Laltu Sardar
Collaborators: NA
Acknowledgements: NA
Time Spent: 
************************************************************/

#include<stdio.h>
#include<stdlib.h>

//declaration of functions and passing argument types
int * myMalloc(int );
int if_palindrome(int * , int );


